DOLLY ASSISTANCE PROTOTYPE

This is a professional, responsive prototype. It is explicitly labeled unofficial and should not be presented as authorized by Dolly Parton, her estate, management, or a charity without verification.

Email destination shown in Contact: dollypartoncharitygiveaway@gmail.com

IMPORTANT: The application currently runs in DEMO MODE and does not send real email. Before collecting real applications, connect a verified email/backend service and update the program's verified legal/contact details.

Files:
- index.html
- apply.html
- contact.html
- css/style.css
- js/app.js
